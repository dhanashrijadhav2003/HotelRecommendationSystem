let app=require("./src/app.js");

let PORT=9999;
app.listen(PORT,()=>{
    console.log("Server Started...");
});